//
//  API_GeneratorApp.swift
//  API_Generator
//
//  Created by Mert on 10/16/25.
//

import SwiftUI

@main
struct API_GeneratorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
