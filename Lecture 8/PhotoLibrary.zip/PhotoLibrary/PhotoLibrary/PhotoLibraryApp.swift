//
//  PhotoLibraryApp.swift
//  PhotoLibrary
//
//  Created by Mert on 10/14/25.
//

import SwiftUI

@main
struct PhotoLibraryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
