//
//  CatExplorerApp.swift
//  CatExplorer
//
//  Created by Andrew Lee on 10/23/25.
//

import SwiftUI

@main
struct CatExplorerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
