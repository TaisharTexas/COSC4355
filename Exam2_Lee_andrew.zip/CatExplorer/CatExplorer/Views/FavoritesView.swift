//
//  FavoritesView.swift
//  CatExplorer
//
//  Created by Andrew Lee on 10/23/25.
//

import SwiftUI

struct FavoritesView: View{
    @EnvironmentObject var service: CatAPIService

    
    var body: some View{
        Text("Fav view")
    }
}
