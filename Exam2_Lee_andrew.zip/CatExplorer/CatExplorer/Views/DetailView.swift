//
//  DetailView.swift
//  CatExplorer
//
//  Created by Andrew Lee on 10/23/25.
//

import SwiftUI

struct DetailView: View{
//    @EnvironmentObject var service: DogAPIService

    
    var body: some View{
        Text("detail view")
    }
}
