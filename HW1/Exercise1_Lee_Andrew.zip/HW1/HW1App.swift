//
//  HW1App.swift
//  HW1
//
//  Created by Andrew Lee on 9/4/25.
//

import SwiftUI

@main
struct HW1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
