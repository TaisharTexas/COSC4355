//
//  HW7_ImageClassifierMLApp.swift
//  HW7_ImageClassifierML
//
//  Created by Andrew Lee on 11/17/25.
//

import SwiftUI

@main
struct HW7_ImageClassifierMLApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
