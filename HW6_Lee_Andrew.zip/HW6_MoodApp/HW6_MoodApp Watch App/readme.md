For new-day handling, I keep all mood records created forever, but the function that loads from the persistant storage to the array that the graph and display blocks use only takes records where the date matches the current day. And then the app rechecks this whenever the internal timer runs down or the app screen switches to active from inactive. 

I didnt do the bonus stuff this time. I did add both sound and vibrate haptics for fun but you cant test that with the simulator. 
