//
//  HW6_MoodAppApp.swift
//  HW6_MoodApp Watch App
//
//  Created by Andrew Lee on 11/6/25.
//

import SwiftUI

@main
struct HW6_MoodApp_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationStack{
                ContentView()
            }
        }
    }
}
