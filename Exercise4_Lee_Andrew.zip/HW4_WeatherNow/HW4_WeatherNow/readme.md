
I pickd Custom Icon/Splash, New Color Scheme, and Typography (there some light fades and stuff too, but the other three I did more of)

For icon the icon I googled weather app icon and picked one I thought would look good on both a light and dark background and the splash I picked one of my main blue colors
For the Color Scheme I based a lot of my color choices off the iOS weather app. I also mimiced the layout of it too somewhat with the search bar at the bottom and the partially transparent cards that change color. I didnt go find a specific color palate but pretty much just tried get the vibe of the iOS colors without exactly copying it. 
And for Typography I pretty much just changed the main font. I ended up with a few specific font styles for stuff like temperatures, and I even grabbed a seperate monospace font that I use just for numbers, but other than that its pretty much redefining the default font styles with a new font. 

I also added the toggle in settings that swtiches between metric and imperial for everything. 
