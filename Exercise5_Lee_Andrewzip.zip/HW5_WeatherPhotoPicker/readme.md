
I pulled as much code from HW4 as I could to repurpose for this 

For the extra credit, I added a settings tab that lets you swap metric and imperial and I also added some more details to the city weather display
("add" is maybe a bit facetious...I pretty much copied my h4 code for these and deleted a bunch of unused stuff)
