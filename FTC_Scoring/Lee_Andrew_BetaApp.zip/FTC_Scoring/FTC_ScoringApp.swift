//
//  FTC_ScoringApp.swift
//  FTC_Scoring
//
//  Created by Andrew Lee on 9/29/25.
//

import SwiftUI

@main
struct FTC_ScoringApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
