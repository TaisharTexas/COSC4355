//
//  Exam3_Lee_AndrewApp.swift
//  Exam3_Lee_Andrew Watch App
//
//  Created by Andrew Lee on 11/20/25.
//

import SwiftUI

@main
struct Exam3_Lee_Andrew_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
